package model.repository;

import config.DatabaseConnectionConfig;
import constants.StudentSQL;
import model.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentRepository {
    public static Student findById(int id) {
        try (Connection con = DatabaseConnectionConfig.getConnection();
             PreparedStatement statement = con.prepareStatement(StudentSQL.SELECT_BY_ID)) {
                statement.setInt(1, id);
                ResultSet rs = statement.executeQuery();
                if (rs.next()) {
                    Student student = new Student();
                    student.setId(rs.getInt("id"));
                    student.setName(rs.getString("name"));
                    student.setAge(rs.getInt("age"));
                    student.setEmail(rs.getString("email"));
                    student.setGrade(rs.getString("grade").charAt(0));
                    student.setScore(rs.getDouble("score"));
                    return student;
                }
        } catch (Exception e) {
            System.out.println("Not found student by ID: " + e.getMessage());
        }
        return null;
    }

    public static List<Student> findAllStudents() {
        List<Student> studentList = new ArrayList<>();
        try (Connection con = DatabaseConnectionConfig.getConnection();
             Statement st = con.createStatement()){
                 ResultSet rs = st.executeQuery(StudentSQL.SELECT_ALL);
                    while (rs.next()) {
                        Student student = new Student();
                        student.setId(rs.getInt("id"));
                        student.setName(rs.getString("name"));
                        student.setAge(rs.getInt("age"));
                        student.setEmail(rs.getString("email"));
                        student.setGrade(rs.getString("grade").charAt(0));
                        student.setScore(rs.getDouble("score"));
                        studentList.add(student);
                    }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        return studentList;
    }

    public static void insertStudent(Student student) {
        try(Connection con = DatabaseConnectionConfig.getConnection();
            PreparedStatement statement = con.prepareStatement(StudentSQL.INSERT)) {
                statement.setString(1, student.getName());
                statement.setInt(2, student.getAge());
                statement.setString(3, student.getEmail());
                statement.setString(4, String.valueOf(student.getGrade()));
                statement.setDouble(5, student.getScore());
                int rowAffected = statement.executeUpdate();
                if(rowAffected>0){
                    System.out.println("New Student "+ student.getName()+" has been inserted");
                    return;
                }
            System.out.println("Cannot insert Student");
        }catch (Exception exception){
            System.out.println("Problem during insert new student: " + exception.getMessage());
        }
    }

    public static int deleteStudent(int id){
        try(Connection con = DatabaseConnectionConfig.getConnection();
            PreparedStatement statement = con.prepareStatement(StudentSQL.DELETE)){
                statement.setInt(1, id);
                int rowAffected = statement.executeUpdate();
                if(rowAffected>0){
                    System.out.println("student "+ id +" has been deleted");
                    return rowAffected;
                }
            System.out.println("Cannot delete student");
        }catch (Exception exception){
            System.out.println("Problem during delete student: " + exception.getMessage());
        }
        return 0;
    }

    public static Student updateStudent(Student student){
        try(Connection con = DatabaseConnectionConfig.getConnection();
                PreparedStatement statement = con.prepareStatement(StudentSQL.UPDATE)){
                    statement.setString(1, student.getName());
                    statement.setInt(2, student.getAge());
                    statement.setString(3, student.getEmail());
                    statement.setString(4, String.valueOf(student.getGrade()));
                    statement.setDouble(5, student.getScore());
                    statement.setInt(6, student.getId());
                    int rowAffected = statement.executeUpdate();

                    if(rowAffected>0){
                        System.out.println("Student has been updated. ID: " + student.getId());
                        return null;
                    }else {
                        System.out.println("No student found with ID: " + student.getId());
                        return null;
                    }
                }
        catch (Exception exception){
            System.out.println("Problem during update the student: "  +exception.getMessage());
        }
        return null;
    }

    public static List<Student> searchStudentByGrade(Character grade) {
        List<Student> studentList = new ArrayList<>();
        try (Connection con = DatabaseConnectionConfig.getConnection();
             PreparedStatement statement = con.prepareStatement(StudentSQL.SELECT_BY_GRADE)) {

                statement.setString(1, grade.toString());
                ResultSet rs = statement.executeQuery();

                while (rs.next()) {
                    Student student = new Student();
                    student.setId(rs.getInt("id"));
                    student.setName(rs.getString("name"));
                    student.setAge(rs.getInt("age"));
                    student.setEmail(rs.getString("email"));
                    student.setGrade(rs.getString("grade").charAt(0));
                    student.setScore(rs.getDouble("score"));
                    studentList.add(student);
                }
        } catch (Exception e) {
            System.out.println("Not found student by ID: " + e.getMessage());
        }
        return studentList;
    }

    public static List<Student> getStudentsByMinScore(double minScore) {
        List<Student> students = new ArrayList<>();
        try (Connection con = DatabaseConnectionConfig.getConnection();
             PreparedStatement statement = con.prepareStatement(StudentSQL.SELECT_BY_MIN_SCORE)) {
                statement.setDouble(1, minScore);
                ResultSet rs = statement.executeQuery();

                while (rs.next()) {
                    Student student = new Student();
                    student.setId(rs.getInt("id"));
                    student.setName(rs.getString("name"));
                    student.setAge(rs.getInt("age"));
                    student.setEmail(rs.getString("email"));
                    student.setGrade(rs.getString("grade").charAt(0));
                    student.setScore(rs.getDouble("score"));
                    students.add(student);
                }
            } catch (Exception e) {
                System.out.println("Error fetching students by min score: " + e.getMessage());
            }
        return students;
    }

    public static double calculateAverageScore() {
        double averageScore = 0.0;
        try (Connection con = DatabaseConnectionConfig.getConnection();
             PreparedStatement statement = con.prepareStatement(StudentSQL.AVG_SCORE)) {
                ResultSet rs = statement.executeQuery();
                if (rs.next()) {
                    averageScore = rs.getDouble("avg_score");
                }
        } catch (Exception e) {
            System.out.println("Error calculating average score: " + e.getMessage());
        }
        return averageScore;
    }
}


