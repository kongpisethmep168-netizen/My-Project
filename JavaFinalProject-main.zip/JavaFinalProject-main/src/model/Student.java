package model;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data

public class Student {
    private Integer id;
    private String name;
    private Integer age;
    private String email;
    private Character grade;
    private Double score;

}
