package service;

import model.Student;
import model.repository.StudentRepository;

import java.util.List;

public class StudentService {

    public static void addStudent(Student student) {
        StudentRepository.insertStudent(student);
    }

    public static Student getStudentById(int id) {
        return StudentRepository.findById(id);
    }

    public static List<Student> getAllStudents() {
        return StudentRepository.findAllStudents();
    }

    public static void updateStudent(Student student) {
        StudentRepository.updateStudent(student);
    }

    public static void deleteStudent(int id) {
        StudentRepository.deleteStudent(id);
    }

    public double getAverageScore() {
        return StudentRepository.calculateAverageScore();
    }
    public List<Student> getStudentsByGrade(Character grade){
        StudentRepository.searchStudentByGrade(grade);
        return StudentRepository.searchStudentByGrade(grade);
    }
    public static List<Student> getStudentsByMinScore(double minScore){
        StudentRepository.getStudentsByMinScore(minScore);
        return StudentRepository.getStudentsByMinScore(minScore);
    }
}

