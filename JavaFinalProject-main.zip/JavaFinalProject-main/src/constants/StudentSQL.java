package constants;

public class StudentSQL {

    public static final String SELECT_BY_ID = """
        SELECT * FROM students WHERE id = ?
    """;

    public static final String SELECT_ALL = """
        SELECT * FROM students
    """;

    public static final String INSERT = """
        INSERT INTO students(name, age, email, grade, score)
        VALUES(?,?,?,?,?)
    """;

    public static final String DELETE = """
        DELETE FROM students
        WHERE id = ?
    """;

    public static final String UPDATE = """
        UPDATE students
        SET name = ?, age = ?, email = ?, grade = ?, score = ?
        WHERE id = ?
    """;

    public static final String SELECT_BY_GRADE = """
        SELECT * FROM students WHERE grade = ?
    """;

    public static final String SELECT_BY_MIN_SCORE = """
        SELECT * FROM students WHERE score >= ? ORDER BY score DESC
    """;

    public static final String AVG_SCORE = """
        SELECT AVG(score) AS avg_score FROM students
    """;
}
