package view;

import model.Student;
import service.StudentService;

import java.util.List;
import java.util.Scanner;

public class UI {
    static Scanner scanner = new Scanner(System.in);
    private static final StudentService studentService = new StudentService();
    public static void thumbnails(){
        System.out.println("""
                =====================
                        Menu
                =====================
                1.Add Student
                2.View Students
                3.Update Student
                4.Delete Student
                5.Search Students by Grade
                6.List Top-Performing Students
                7.Calculate Average Score
                8.Exit
                -------""");
    }
    public static int option(){
        System.out.print("Choose: ");
        return new Scanner(System.in).nextInt();
    }

    public static void home(){
        while (true){
            thumbnails();
            switch (option()){
                case 1-> {
                    System.out.println("Enter Student datils:");
                    System.out.print("Name:");
                    String name = scanner.nextLine().trim();
                    int age = -1;
                        while (true) {
                            try {
                                System.out.print("Age: ");
                                age = Integer.parseInt(scanner.nextLine());
                                if (age <= 0) {
                                    System.out.println("Age must be a positive number.");
                                    continue;
                                }
                                break;
                            } catch (NumberFormatException e) {
                                System.out.println("Invalid input. Please enter a valid integer for age.");
                            }
                        }
                    String email = "";
                        while (true) {
                            System.out.print("Email: ");
                            email = scanner.nextLine().trim();
                            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                                System.out.println("Invalid email format. Try again.");
                                continue;
                            }
                            break;
                        }
                    char grade;
                    while (true) {
                        System.out.print("Grade (A/B/C/D/F): ");
                        grade = scanner.nextLine().trim().toUpperCase().charAt(0);
                        if ("ABCDF".indexOf(grade) == -1) {
                            System.out.println("Invalid grade. Must be one of A, B, C, D, F.");
                            continue;
                        }
                        break;
                    }
                    double score = -1;
                        while (true) {
                            try {
                                System.out.print("Score (0-100): ");
                                score = Double.parseDouble(scanner.nextLine());
                                if (score < 0 || score > 100) {
                                    System.out.println("Score must be between 0 and 100.");
                                    continue;
                                }
                                break;
                            } catch (NumberFormatException e) {
                                System.out.println("Invalid input. Please enter a number for score.");
                            }
                        }

                    Student student = new Student();
                    student.setName(name);
                    student.setAge(age);
                    student.setEmail(email);
                    student.setGrade(grade);
                    student.setScore(score);
                    studentService.addStudent(student);
                    System.out.println("Student inserted successfully!");
                }
                case 2->{
                    System.out.println("Student List:");
                    StudentService.getAllStudents().stream()
                            .forEach(System.out::println);
                }
                case 3->{
                    System.out.print("Enter Student ID to update:");
                    int id = scanner.nextInt();
                    scanner.nextLine();

                    Student existingStudent = StudentService.getStudentById(id);
                    if (existingStudent == null) {
                        System.out.println("No student found with ID: " + id);
                    } else {
                        System.out.print("Name: ");
                        String name = scanner.nextLine().trim();

                        int age = -1;
                        while (true) {
                            try {
                                System.out.print("Age: ");
                                age = Integer.parseInt(scanner.nextLine());
                                if (age <= 0) {
                                    System.out.println("Age must be a positive number.");
                                    continue;
                                }
                                break;
                            } catch (NumberFormatException e) {
                                System.out.println("Invalid input. Please enter a valid integer for age.");
                            }
                        }

                        String email = "";
                        while (true) {
                            System.out.print("Email: ");
                            email = scanner.nextLine().trim();
                            if (!email.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                                System.out.println("Invalid email format. Try again.");
                                continue;
                            }
                            break;
                        }

                        char grade;
                        while (true) {
                            System.out.print("Grade (A/B/C/D/F): ");
                            grade = scanner.nextLine().trim().toUpperCase().charAt(0);
                            if ("ABCDF".indexOf(grade) == -1) {
                                System.out.println("Invalid grade. Must be one of A, B, C, D, F.");
                                continue;
                            }
                            break;
                        }

                        double score = -1;
                        while (true) {
                            try {
                                System.out.print("Score (0-100): ");
                                score = Double.parseDouble(scanner.nextLine());
                                if (score < 0 || score > 100) {
                                    System.out.println("Score must be between 0 and 100.");
                                    continue;
                                }
                                break;
                            } catch (NumberFormatException e) {
                                System.out.println("Invalid input. Please enter a number for score.");
                            }
                        }
                        Student student = new Student();
                        student.setId(id);
                        student.setName(name);
                        student.setAge(age);
                        student.setEmail(email);
                        student.setGrade(grade);
                        student.setScore(score);
                        studentService.updateStudent(student);
                        System.out.println("Student updated successfully!");
                    }
                }
                case 4->{
                    System.out.print("Enter Student ID to delete:");
                    int id = scanner.nextInt();
                    studentService.deleteStudent(id);
                    System.out.println("Student deleted successfully!");
                }
                case 5->{
                    System.out.print("Enter Grade to search: ");
                    char grade = scanner.next().charAt(0);
                    grade = Character.toUpperCase(grade);

                    if (grade != 'A' && grade != 'B' && grade != 'C' && grade != 'D' && grade != 'F') {
                        System.out.println("Invalid grade! Please enter one of A, B, C, D, F.");
                    } else {
                        List<Student> studentsByGrade = studentService.getStudentsByGrade(grade);
                        if (studentsByGrade.isEmpty()) {
                            System.out.println("No students found with grade: " + grade);
                        } else {
                            studentsByGrade.forEach(System.out::println);
                        }
                    }
                }
                case 6->{
                    System.out.print("Enter minimum score to filter students: ");
                    double minScore = scanner.nextDouble();
                    scanner.nextLine();
                    if(minScore <= 0 || minScore > 100) {
                        System.out.println("Please enter a value between 1 and 100.");
                    }else {
                        List<Student> students = studentService.getStudentsByMinScore(minScore);
                        System.out.println("=== Students with score >= " + minScore + " ===");
                        if (students.isEmpty()) {
                            System.out.println("No students found.");
                        } else {
                            students.forEach(System.out::println);
                        }
                    }
                }
                case 7->{
                    double avgScore = studentService.getAverageScore();
                    System.out.printf("Average score of all students: %.2f%n", avgScore);
                }
                case 8->{
                    System.out.println("        Exit        ");
                    System.exit(0);
                }
                default -> System.out.println("[!]Invalid Choose :(");
            }
        }
    }
}
